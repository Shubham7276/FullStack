exports.user = async (req, res) => {
	try {
		res.status(200).json("Content")
	} catch (err) {
		console.error(err.message)
	}
}
exports.pm = async (req, res) => {
	try {
		res.status(200).json("Content")
	} catch (err) {
		console.error(err.message)
	}
}
exports.admin = async (req, res) => {
	try {
		res.status(200).json("Content")
	} catch (err) {
		console.error(err.message)
	}
}
