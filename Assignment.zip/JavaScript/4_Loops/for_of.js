//for-of loop its good for array, list

let Bike=["Hero","Yamaha","Honda","TVS"];
for(b of Bike){
    document.write("<br/>",b);
}

document.write("<hr/>")

// for-in loop its good for json object 

var demo={
  Id:1001,
  name:"Ram",
  Sub:"Math"

}

for(d in demo){
    document.write("<br/>"+d+" : "+demo[d]);
}