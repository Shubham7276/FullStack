const student={
    RollNo:1,
    Name:"Vaibhav",
    Degree:"MCA",
    ifApplicable:true,

    showStatus(){
        const eligible=this.ifApplicable?"If is applicable":"If is not applicable";
        document.write("<br/>Roll No "+student.RollNo+" "+student.Name+" "+student.Degree+" Marks "+this.marks+" "+eligible);
    }
};

const s= Object.create(student);
s.marks="59";
s.showStatus();

const sc= Object.create(s);
sc.showStatus();

// Access object keys - keys method.

const self={
    name:"Vishal",Age:25,Class:"BCA"
}

// Get the keys of the object

const keys= Object.keys(self);
document.write("<br/>"+keys);


// Get the values of the object

const values= Object.values(self);
document.write("<br/>"+values)

// Iterate through the keys

Object.keys(self).forEach(key=>{
    let value = self[key];
    document.write("<br/>"+key+":"+value);
});


// Get the object key/value pairs Object.entries()

const c=Object.entries(self);
document.write("<br/><br/>"+c);

// Object.assign() is used to copy values from one object to another.

const personone ={
    firstname:"Kishan",
    lastname:"More"
}

const persononetwo={
    Person2:"Neha",
    person3:"More" 
}

// Merge the objects with assign

const p=Object.assign(personone,persononetwo);
document.write("<br/><br/>"+JSON.stringify(p));

// Merge the object with the spread operator.

const pp={...personone,...persononetwo}
document.write("<br/><br/>"+JSON.stringify(pp));

//________________________________________________________
//Freeze object
const user ={
    username:"abc@rdiff",
    pass:"absd"
};

const u1=Object.freeze(user);
u1.pass="***********";
u1.active=true;

document.write("<br/></br>"+JSON.stringify(u1));


// Seal the object

const user1 ={
    username:"abc@rdiff",
    pass:"absd"
};


const u2=Object.seal(user1);
u2.pass="***********";
u2.active=true;

document.write("<br/></br>"+JSON.stringify(u2));

//Object.getprototypeof()

const persons = ['ABC', 'DEF', 'GHI', 'JKL'];
document.write("<br/><br/>"+Object.getPrototypeOf(persons)===Array.prototype);