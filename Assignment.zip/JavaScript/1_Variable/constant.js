try{
    const c=199;
    c=200;
    document.write(d);
}
catch(err){
    document.write(err)
}