let a=10;
let b=20;
var c=a+b;

document.write("Simple Addition of two No."+c+"<br/>");


// Difference of let,var and const varibale

// calling var d before definition will return undefined
document.write(d);
var d=10;


// calling let e before definition will return error check in console
document.write(e);
let e=10;

// calling let a before definition will give error

const f=5;
f=6;
document.write(f)








