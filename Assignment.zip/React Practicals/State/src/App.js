import logo from './logo.svg';
import './App.css';

import { BrowserRouter, Routes, Route } from "react-router-dom";
import ClassComponent from './Components/ClassComponent';
import UpdateclassComponant from './Components/UpdateclassComponant';
import UseStateFun from './Components/UseStateFun';


function App() {
  return (
    <>
    <ClassComponent></ClassComponent>
    <UpdateclassComponant></UpdateclassComponant>
    <UseStateFun></UseStateFun>
    </>
  );
}

export default App;
