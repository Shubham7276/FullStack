import React from 'react'

class ClassComponent extends React.Component{
  constructor(props){
    super(props);
      this.state={
        name:"Shubham Chaudhari",
        ContactNo:"7865432456",
        Salery:10000
      };
    
  }


  render(){
    return (
    <>
    <h4>My name {this.state.name} ,Contact no is {this.state.ContactNo} ,Salery {this.state.Salery}</h4>
    </>
    )
  }
}

export default ClassComponent;