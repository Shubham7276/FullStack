import React, { useState } from 'react'

function UseStateFun(){
    const [count, setCount] = useState(0)

    return(
        <>
        <h3>You Clicked {count} times Button</h3>
        <button onClick={()=>setCount(count+1)}>Click here</button>
        </>
    )
}

export default UseStateFun;