import React from 'react'

class UpdateclassComponant extends React.Component{
    constructor(props){
        super(props);
            this.state = {
                name:'Shubham Chaudhari',
                ContactNo:'7639483900',
                salery:90000
            }
        
    }

    updateSalery=() =>{
        this.setState({salery:12000});
    }

    render(){
        return(
            <>
            <hr />
            <h3>My Name is {this.state.name}</h3>
            <h3>My Contact No is {this.state.ContactNo}</h3>
            <h3>My Salery is {this.state.salery}</h3>
            <button type='button' onClick={this.updateSalery}>Update Salary</button>
            <hr />
            </>
        )
    }
}

export default UpdateclassComponant;
