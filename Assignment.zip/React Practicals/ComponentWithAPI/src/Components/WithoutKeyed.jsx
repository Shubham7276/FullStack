import React from "react";

function CountryListWithoutKey(props) {
    return (
      <dl>
        {props.countriesWithoutKeys.map((country,index) => (
          // Only do this if items have no stable IDs
          <React.Fragment key={index}>
            <dt>{country.name}</dt>
            <dd>{country.capital}</dd>
          </React.Fragment>
        ))}
      </dl>
    );
  
}

export default CountryListWithoutKey;