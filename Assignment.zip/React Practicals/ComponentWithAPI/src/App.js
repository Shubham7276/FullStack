import './App.css';
//import ForceUpdate from './Components/ForceUpdate';
// import CountryList from './Components/KeyedFragment';
// import CountryListWithoutKey from './Components/WithoutKeyed';
import ComponentAPIDemo from './Components/ComponentApi';


function App() {
  const countries = [
    {id: 1, name: 'India', capital: 'Delhi'},
    {id: 2, name: 'USA', capital: 'Washington DC'},
    {id: 3, name: 'Spain', capital: 'Madrid'}
  ];

  const countriesWithoutKeys = [
    {name: 'India', capital: 'Delhi'},
    {name: 'USA', capital: 'Washington DC'},
    {name: 'Spain', capital: 'Madrid'}
  ];
  return (
    <ComponentAPIDemo/>
    // <ForceUpdate/>
    // <CountryList countries={countries}/>
    // <CountryListWithoutKey countriesWithoutKeys={countriesWithoutKeys}/>
  );
}

export default App;
