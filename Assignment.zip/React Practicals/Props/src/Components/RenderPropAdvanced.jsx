import React, { Component } from 'react'

class PersoneCompany extends Component {
  render() {
    return (
      <div>
          <h1>PersoneCom Move the mouse around!</h1>

          <Company
          render={mouse=>(<Person mouse={mouse}/>)}
          />

        </div>
    )
  }
}

//Parent Class


class Company extends Component {
    constructor(props){
        super(props);
        this.handleMouseMove=this.handleMouseMove.bind(this);
        this.state = { x: 0, y: 0 };
    }

    handleMouseMove(event){
        this.setState({
            x: event.clientX,
            y: event.clientY
        });
    }


    render() {
        return (
            <div style={{height:'200px'}} onMouseMove={this.handleMouseMove}>
                {this.props.render(this.state)}

            </div>
        )
    }
}


//Child Class

class Person extends React.Component {
    render() {
      const mouse = this.props.mouse;
      return (
          <>
            <div>{mouse.x} - {mouse.y}</div>
            <img src={process.env.PUBLIC_URL + '/sky9.png'} style={{ position: 'absolute', left: mouse.x, top: mouse.y }} alt='Sky9' />
         </>
      );
    }
  }
  

export default PersoneCompany

