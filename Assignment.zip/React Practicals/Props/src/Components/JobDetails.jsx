import React from 'react';
import ReactDOM from 'react-dom';
import Person from './BasicDetails'


function JobDetails() {
  const personJobInfo = { designation: "Sr. Front End Developer", salary: 100000 };
  return (
    <>
	    <Person personJobData={personJobInfo} />
    </>
  );
}

 ReactDOM.render(<JobDetails />, document.getElementById('root'));

export default JobDetails