import React from 'react'
import '../index.css'
class ThirdComponant extends React.Component{
    render(){
        return <h2 className='ext'>Third Componant using external style</h2>
    }
}

export default ThirdComponant;