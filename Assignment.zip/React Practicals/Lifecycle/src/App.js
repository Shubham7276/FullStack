
import './App.css';
import LifeCycle from './Components/LifeCycle';

function App() {
  return (
    <>
    <LifeCycle></LifeCycle>
    </>
  );
}

export default App;
