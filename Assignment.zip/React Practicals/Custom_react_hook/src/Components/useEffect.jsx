import React, { useState, useEffect } from 'react'

function UserEffectdemo(){
    const [count, setCount] = useState(0);
    


    function resetCounter(){
        setCount(count + 1)
        

    }
    useEffect(()=>{
        
        document.title = `You click ${count} times`
    });

    return (
        <div>
            <p>click {count} times </p>
            <button onClick={resetCounter}>Like</button>
            <button onClick={()=> setCount(count-1)}>Dislike</button>
        </div>
    )
}
export default UserEffectdemo;



