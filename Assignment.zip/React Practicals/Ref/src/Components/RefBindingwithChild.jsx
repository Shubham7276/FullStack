import { forwardRef, useImperativeHandle } from "react";
import ParentComp from "./RefBindingwithParent";

const ChildComp = forwardRef((props, ref)=>{
    useImperativeHandle(ref,()=>({
        showAlert(){
            {}
             alert("Hello from Child Componant")
        },
    }))
    return <div></div>
})





export default ChildComp;