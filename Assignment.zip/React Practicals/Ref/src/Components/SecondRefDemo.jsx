import React, { Component } from 'react'
import ReactDOM from 'react-dom'


export default class SecondRef extends Component {
    constructor(){
        super();
        this.state={Count:0}
    }

    updateCallback=(e)=>{
        this.setState({Count: this.counterRef.value})
    }

  render() {
    return (
      <div>
          Counts <input type="text" ref={(call_back)=> {this.counterRef= call_back}} onChange ={this.updateCallback}></input>
          <br />
          <p>{this.state.Count}</p>
      </div>
    )
  }
}
