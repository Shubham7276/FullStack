import React, {useRef} from 'react';
 import ChildComp from './RefBindingwithChild';


export default function ParentComp(props){
    const childCompRef = useRef()
    return(
        <div>
             <button onClick={() => childCompRef.current.showAlert()}>Click Me</button>
            <ChildComp ref={childCompRef} />
            
        </div>
    )
}