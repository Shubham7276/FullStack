import React from 'react'
import ReactDOM from 'react-dom'

// With out using Hooks - useRef().    //CreateRef
class FirstRef extends React.Component {
    constructor(){
        super();
        
        this.state = { count: 0};
    }
    
    
    updateUsingRef=(e)=>{
        this.setState({count:this.refs.counterRef.value});
    }

  render() {
    return (
      <div>
          Count <input type="text" ref="counterRef" onChange = {this.updateUsingRef}></input>
          <br/>
          <p>{this.state.count}</p>
      </div>
    );
  }
}


export default FirstRef