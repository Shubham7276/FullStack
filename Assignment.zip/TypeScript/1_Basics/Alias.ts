//Alise

type num=number;
let demo:num;
demo=10;
console.log(demo)


//Union datatype
type alphnumeric=number|string;
let U:alphnumeric;

U=11;
console.log(U);
U="UnionType"
console.log(U);
