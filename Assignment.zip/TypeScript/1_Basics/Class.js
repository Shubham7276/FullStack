var cls = /** @class */ (function () {
    function cls() {
    }
    cls.prototype.demo = function () {
        console.log("Hello Bhailog");
    };
    return cls;
}());
var obj = new cls();
obj.demo();
