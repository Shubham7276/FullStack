// Annotation as a parameter.
function Show(id, name) {
    console.log("ID:" + id + " Name:" + name);
}
Show(1, "Tushar");
//Inline Annotation.
var Per;
Per = {
    id: 1,
    Name: "Divya"
};
console.log("Id:" + Per.id + " Name:" + Per.Name);
//Type Interface
function Add(a, b) {
    return a + b;
}
var Sum = Add(20, 22);
console.log(typeof Sum);
console.log("Addition Of Two No:" + Sum);
