// Annotation as a parameter.

function Show(id:number,name:string){
    console.log("ID:"+id +" Name:"+name)
}
Show(1,"Tushar");

//Inline Annotation.

var Per:{
    id:number;
    Name:string;
};

Per={
    id:1,
    Name:"Divya"
};

console.log("Id:"+Per.id+" Name:"+Per.Name);

//Type Interface

function Add(a:number,b:number){
    return a+b;
}
let Sum=Add(20,22);
console.log(typeof Sum);
console.log("Addition Of Two No:"+Sum);

