class person{
    private _age:number;

    public get age(){
        return this._age;
    }

    public set age(Theage:number){
        if(Theage<=0 || Theage>=100){
            throw new Error('The age is invalid');
        }
        
        this._age=Theage;
    }

    public getAge():number{
        return this._age;
    }
}

var obj=new person();
obj.age=120;
console.log(obj.getAge());