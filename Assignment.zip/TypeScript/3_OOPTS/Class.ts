class person{
    firstName:string;
    lastName:string;

    constructor(firstName1:string,lastName1:string){
        this.firstName=firstName1;
        this.lastName=lastName1;
    }

    //function
    show():void{
        console.log("Person Details: "+this.firstName+" " +this.lastName);
    }
}

var obj=new person("Rakesh","Rane");
obj.show();