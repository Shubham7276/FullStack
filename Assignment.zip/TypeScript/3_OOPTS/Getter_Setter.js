var person = /** @class */ (function () {
    function person() {
    }
    Object.defineProperty(person.prototype, "age", {
        get: function () {
            return this._age;
        },
        set: function (Theage) {
            if (Theage <= 0 || Theage >= 100) {
                console.log('The age is invalid');
            }
            this._age = Theage;
        },
        enumerable: false,
        configurable: true
    });
    person.prototype.getAge = function () {
        return this._age;
    };
    return person;
}());
var obj = new person();
obj.age = 120;
console.log(obj.getAge());
