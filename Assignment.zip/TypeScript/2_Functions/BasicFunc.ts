function add(a:number,b:number):number{
    return a+b;
}

console.log(add(2,2));


function show(collection:string):void{
    console.log(collection.toUpperCase());
}
show("shubham");


let addNum:(x:number,y:number)=>number;



let addNum1=function (x:number,y:number){
    return x+y;
};

console.log(addNum1(33,33))


let addNum2:(a:number,b:number)=>number=
    function (x:number,y:number){
        return x+y;
    }

console.log(addNum2(2,2))