// let inBoolOptions: DTOptions<boolean> = {
//     'disabled': false,
//     'visible': true
// };
// let inBoolOptions1: DTOptions<number>={
//     "Num1":11
// }
var demo = /** @class */ (function () {
    function demo() {
    }
    demo.prototype.show = function (d) {
        this.name = d;
    };
    return demo;
}());
var d1 = new demo();
d1.show("ccccc");
console.log(d1);
