"use strict";
exports.__esModule = true;
exports.Constant = void 0;
var Constant = /** @class */ (function () {
    function Constant() {
    }
    Constant.emailReg = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    Constant.NumberReg = /^[0-9]+$/;
    Constant.NameReg = /^([a-zA-Z ]{2,40})$/;
    return Constant;
}());
exports.Constant = Constant;
