import { Validatorcls } from "./validators/validators";
import{Constant} from "./constant/constant"

let name="Shubham"
let email="abcxyz@gmail.com";
let adhaar="342578324537"
let mobile="9847646388"
let zipcode='221333';





let validator=new Validatorcls();

var valid=validator.isValid(name,Constant.NameReg,2,10)
console.log("zipcod is valid or not : "+valid)

var valid=validator.isValid(email,Constant.emailReg)
console.log("Email is valid or not : " +valid)

var valid=validator.isValid(zipcode,Constant.NumberReg,6)
console.log("zipcod is valid or not : "+valid)

var valid=validator.isValid(mobile,Constant.NumberReg,10)
console.log("zipcod is valid or not : "+valid)

var valid=validator.isValid(adhaar,Constant.NumberReg,12)
console.log("Adhaar no. is valid or not : "+valid)