export interface I1{
    
    isValid(s:string,Regex,min?:number,max?:number):boolean
}