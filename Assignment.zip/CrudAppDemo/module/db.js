const mongoose = require('mongoose')
const url='mongodb://localhost:27017/EmployeeDB'

mongoose.connect(url,{useNewParser:true},(err)=>{
    if(!err){ console.log("Connect Success...!"); }
    else{ console.log("Error : " + err); }


})