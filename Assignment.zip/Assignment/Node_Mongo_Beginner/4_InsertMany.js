var MongoClient=require('mongodb').MongoClient
var url='mongodb://localhost:27017/'

MongoClient.connect(url,function(err,db){
    if(err) throw err;
    var dbo=db.db('staffdb')
    var many=[
        {name:"Vaibhav",Contact_No:9873678822},
        {name:"Yogesh",Contact_No:9865578822},
        {name:"Krishna",Contact_No:8822987367}
    ]
    dbo.collection('staff_Info').insertMany(many,function(err,res){
        if(err) throw err;
        console.log("Many Record inserted...!")
        db.close()
    })
})