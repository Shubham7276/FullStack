var MongoClient=require('mongodb').MongoClient
var url='mongodb://localhost:27017/'


MongoClient.connect(url,function(err,db){
    if(err) throw err;
    var dbo=db.db("staffdb")
    var insert={name:"Nilesh",Contact_No:7783763728}
    dbo.collection("staff_Info").insertOne(insert,function(err,res){
        if(err) throw err;
        console.log("One Record Inserted..!")
        db.close();
    });
});