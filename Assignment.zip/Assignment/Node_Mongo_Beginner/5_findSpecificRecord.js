var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";


//Showall Records

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("staffdb");
  dbo.collection('staff_Info').find({}).toArray(function(err,res){
      if (err) throw err;
      console.log(res);
      db.close();
  })
});

//Show specific Record
// MongoClient.connect(url, function(err, db) {
//     if (err) throw err;
//     var dbo = db.db("staffdb");
//     var specific={name:"Nilesh"}
//     dbo.collection('staff_Info').find(specific).toArray(function(err,res){
//         if (err) throw err;
//         console.log(res);
//         db.close();
//     })
//   });

//Sorting
  // MongoClient.connect(url, function(err, db) {
  //   if (err) throw err;
  //   var dbo = db.db("staffdb");
  //   var msort={name:1}
  //   dbo.collection('staff_Info').find().sort(msort).toArray(function(err,res){
  //       if (err) throw err;
  //       console.log(res);
  //       db.close();
  //   })
  // });
  
  
