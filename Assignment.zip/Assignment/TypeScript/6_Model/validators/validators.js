"use strict";
exports.__esModule = true;
exports.Validatorcls = void 0;
var Validatorcls = /** @class */ (function () {
    function Validatorcls() {
    }
    Validatorcls.prototype.isValid = function (s, Regex, min, max) {
        if (min == undefined && max == undefined) {
            return Regex.test(s);
        }
        else if (max == undefined) {
            max = min;
        }
        return s.length >= min && s.length <= max && Regex.test(s);
    };
    return Validatorcls;
}());
exports.Validatorcls = Validatorcls;
