import {I1} from '../interface/interface'


class Validatorcls implements I1{
   

    isValid(s: string, Regex, min?: number, max?: number): boolean {
        if(min==undefined && max==undefined){
            return Regex.test(s);
        }
        else if(max==undefined){
            max=min
        }
        return s.length>=min && s.length<=max && Regex.test(s)
    }
}

export{Validatorcls}