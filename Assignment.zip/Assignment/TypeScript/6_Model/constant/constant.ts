export class Constant{
    public static emailReg=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    public static NumberReg=/^[0-9]+$/;
    public static NameReg= /^([a-zA-Z ]{2,40})$/;
}