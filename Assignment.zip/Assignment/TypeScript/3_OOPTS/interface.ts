interface mailable{
    send(email:string,after:number):boolean;
    queue(email:string):boolean;
}

interface FutureMailable extends mailable{
    later(email:string,after:number):boolean;
}

class mail implements FutureMailable{
    later(email: string, after: number): boolean {
        console.log("Send email to"+email+" in "+after+" ms")
        return true;
    }
    queue(email: string): boolean {
        console.log("Queue email to "+email)
        return true;  
    }
    send(email: string, after: number): boolean {
        console.log("Send email to"+email+" in "+after+" ms")
        return true;
    }
}

var M=new mail()
console.log("Leter: "+M.later("abc@mail.com",4));
console.log("Send"+M.send("abc@gmail.com",3))
console.log("Queue: "+M.queue("xyz@gmail.com"))