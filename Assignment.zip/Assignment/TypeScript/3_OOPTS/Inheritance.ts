class shape{
    area:number
    constructor(){
        this.area;
    }
}

class circle extends shape{
    show(a:number):void{
        console.log("Area: "+ a*a)
    }
}

var obj=new circle();
obj.show(20);

// ** Multi level inheritance.

class GrandParentCLS { 
    mes:string="Shubham"; 
 } 
 
 class ParentCLS extends GrandParentCLS {} 
 class ChildCLS extends ParentCLS {} //indirectly inherits from Root by virtue of inheritance  
 
 var obj1 = new ChildCLS(); 
  
 console.log(obj1.mes);

 // static

 class staticcls{
     static num:number;
     static disp():void{
        console.log("The value of num is"+ staticcls.num)
     }
 }

 staticcls.num=19;
 staticcls.disp();

 //Instance of operator

 class Person{ } 
 var Pobj = new Person() 
 var isPerson = Pobj instanceof Person; 
 console.log("Pobj is an instance of Person: " + isPerson);
 
// interface

interface loan{
    interest:number;
}
class personalloan implements loan{
    interest: number;
    rebsate:number;

    constructor(interest: number,rebsate:number){
        this.interest=interest;
        this.rebsate=rebsate;
    }
}

var pl=new personalloan(10,3)
console.log("Interest is: "+pl.interest+" Rebate: "+pl.rebsate)
