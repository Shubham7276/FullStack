var person = /** @class */ (function () {
    function person(firstName1, lastName1) {
        this.firstName = firstName1;
        this.lastName = lastName1;
    }
    //function
    person.prototype.show = function () {
        console.log("Person Details: " + this.firstName + " " + this.lastName);
    };
    return person;
}());
var obj = new person("Rakesh", "Rane");
obj.show();
