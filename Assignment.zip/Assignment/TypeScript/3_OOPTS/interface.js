var mail = /** @class */ (function () {
    function mail() {
    }
    mail.prototype.later = function (email, after) {
        console.log("Send email to" + email + " in " + after + "ms");
        return true;
    };
    mail.prototype.queue = function (email) {
        console.log("Queue email to " + email);
        return true;
    };
    mail.prototype.send = function (email, after) {
        console.log("Send email to" + email + " in " + after + "ms");
        return true;
    };
    return mail;
}());
var M = new mail();
console.log("Leter: " + M.later("abc@mail.com", 4));
console.log("Send" + M.send("abc@gmail.com", 3));
console.log("Queue: " + M.queue("xyz@gmail.com"));
