function num(a, b) {
    return a + b;
}
function str(a, b) {
    return a + b;
}
function numorstr(a, b) {
    if (typeof a === "number" && typeof b === "number")
        return a + b;
    if (typeof a === "string" && typeof b === "string")
        return a + b;
}
console.log(numorstr("Shubham", "Chaudhari"));
console.log(numorstr(101, 102));
console.log(numorstr("aa", 66)); //Return Undefined
function add(a, b) {
    return a + b;
}
console.log(add("Shubham", "Chaudhari"));
function sum(a, b, c) {
    if (c)
        return a + b + c;
    return a + b;
}
console.log("Sum of 2 numbers: " + sum(10, 20));
console.log("Sum of 3 numbers: " + sum(10, 20, 30));
console.log("Sum of 2 numbers from user 3rd is optional: " + sum(10, 20));
// **Method overloading inside the class.
var SumCLS = /** @class */ (function () {
    function SumCLS() {
        this.current = 0;
    }
    SumCLS.prototype.count = function (target) {
        if (target) {
            var values = [];
            for (var start = this.current; start <= target; start++) {
                values.push(start);
            }
            this.current = target;
            return values;
        }
        return ++this.current;
    };
    return SumCLS;
}());
var obj = new SumCLS();
console.log("Number: " + obj.count()); // return a number
console.log("Array of number: " + obj.count(20)); // return an array
var Sum = /** @class */ (function () {
    function Sum() {
    }
    Sum.prototype.sum = function (a, b, c) {
        if (c)
            return a + b + c;
        return a + b;
    };
    return Sum;
}());
var obj1 = new Sum();
console.log(obj1.sum(10, 20));
console.log(obj1.sum(10, 20, 30));
