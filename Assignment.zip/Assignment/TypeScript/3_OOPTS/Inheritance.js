var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var shape = /** @class */ (function () {
    function shape() {
        this.area;
    }
    return shape;
}());
var circle = /** @class */ (function (_super) {
    __extends(circle, _super);
    function circle() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    circle.prototype.show = function (a) {
        console.log("Area: " + a * a);
    };
    return circle;
}(shape));
var obj = new circle();
obj.show(20);
// ** Multi level inheritance.
var GrandParentCLS = /** @class */ (function () {
    function GrandParentCLS() {
        this.mes = "Shubham";
    }
    return GrandParentCLS;
}());
var ParentCLS = /** @class */ (function (_super) {
    __extends(ParentCLS, _super);
    function ParentCLS() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return ParentCLS;
}(GrandParentCLS));
var ChildCLS = /** @class */ (function (_super) {
    __extends(ChildCLS, _super);
    function ChildCLS() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return ChildCLS;
}(ParentCLS)); //indirectly inherits from Root by virtue of inheritance  
var obj1 = new ChildCLS();
console.log(obj1.mes);
// static
var staticcls = /** @class */ (function () {
    function staticcls() {
    }
    staticcls.disp = function () {
        console.log("The value of num is" + staticcls.num);
    };
    return staticcls;
}());
staticcls.num = 19;
staticcls.disp();
//Instance of operator
var Person = /** @class */ (function () {
    function Person() {
    }
    return Person;
}());
var Pobj = new Person();
var isPerson = Pobj instanceof Person;
console.log("Pobj is an instance of Person: " + isPerson);
var personalloan = /** @class */ (function () {
    function personalloan(interest, rebsate) {
        this.interest = interest;
        this.rebsate = rebsate;
    }
    return personalloan;
}());
var pl = new personalloan(10, 3);
console.log("Interest is: " + pl.interest + " Rebate: " + pl.rebsate);
