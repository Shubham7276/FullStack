//** By Using super

class Basecls{
    show():void{
        console.log("Display method from Base class");
    }
}

class Derivedcls extends Basecls{
    show(): void {
        super.show()
        console.log("Display method from Derived Class");
    }

    hello():void{
        console.log("Hello from Child Class!");
    }
}
let bobj=new Basecls();
bobj.show();
let dobj=new Derivedcls();
dobj.show();
dobj.hello();