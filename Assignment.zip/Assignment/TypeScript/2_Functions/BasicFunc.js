function add(a, b) {
    return a + b;
}
console.log(add(2, 2));
function show(collection) {
    console.log(collection.toUpperCase());
}
show("shubham");
var addNum;
var addNum1 = function (x, y) {
    return x + y;
};
console.log(addNum1(33, 33));
var addNum2 = function (x, y) {
    return x + y;
};
console.log(addNum2(2, 2));
