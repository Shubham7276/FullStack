function add(a, b, c) {
    if (typeof c !== 'undefined') {
        return a + b + c;
    }
    return a + b;
}
console.log(add(10, 20));
console.log(add(10, 20, 30));
