class cls{
    demo():void{
        console.log("Hello Bhailog");
    }
}

let obj=new cls();
obj.demo();

