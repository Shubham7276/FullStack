//SIngle Dimenstional Array

let cars:Array<string>=['BMW','Audi','Ford'];
let cars1:string[]=['BMW','Audi','Ford'];
console.log(cars instanceof Object)
console.log(cars1 instanceof Array)
console.log("Cars: "+cars);
console.log("Cars: "+cars1);
console.log("Cars[0]: "+cars[0]);
console.log("Cars[1]: "+cars[1]);
console.log("Cars[2]: "+cars[2]);

//Multi Dimenstion
var Arr:number[][]=[[1,2,3,],[4,5,6]];
console.log(Arr[0][0]);
console.log(Arr[0][1]);  
console.log(Arr[0][2]);  
console.log();  
console.log(Arr[1][0]);  
console.log(Arr[1][1]);  
console.log(Arr[1][2]);


//Array By using Array object

let Aobj:string[]= new Array("Shubham","Khushal","Vishnu");
for(var i=0;i<Aobj.length;i++){
    console.log(Aobj[i]);
}
for(let c of Aobj){
    console.log(c);
}

//Passing Arrays in fuction
let arrparse:string[]=new Array("Nayan","Dev","Dhanush");
function show(a:string[]){
    for(let i=0;i<a.length;i++){
        console.log(arrparse[i]);
    }
}
show(arrparse);

//TypeScript with Spread operator

let arr1 = [ 1, 2, 3];  
let arr2 = [ 4, 5, 6];  

let copyArray = [...arr1];     
console.log("Copy Array With Spread: " +copyArray);  

let copyArray1 = [arr1];     
console.log("Copy Array Without Spread: " +copyArray1);

let newArray = [...arr1, 7, 8];  
console.log("New Array With Spread: " +newArray);  


let newArray1 = [arr1, 7, 8];  
console.log("New Array Without Spread: " +newArray1); 


let mergedArray = [...arr1, ...arr2];  
console.log("Merged Array: " +mergedArray);

let mergedArray1 = [arr1, arr2];  
console.log("Merged Array: " +mergedArray1);