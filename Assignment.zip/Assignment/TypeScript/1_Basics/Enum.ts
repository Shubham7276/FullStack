enum Month{
    Jan,
    Feb,
    Mar,
    Apr,
    May,
    Jun,
    Jul,
    Aug,
    Sep,
    Oct,
    Nov,
    Dec
};

function summer(month:Month){
    let s:boolean;
    switch(month){
        case Month.Jun:
        case Month.Jul:
        case Month.Aug:
            s=true;
            break;
        default:
            s=false;
            break;
    }
    return s;
}
console.log(summer(Month.Jun))