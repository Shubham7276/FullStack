//SIngle Dimenstional Array
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var cars = ['BMW', 'Audi', 'Ford'];
var cars1 = ['BMW', 'Audi', 'Ford'];
console.log(cars instanceof Object);
console.log(cars1 instanceof Array);
console.log("Cars: " + cars);
console.log("Cars: " + cars1);
console.log("Cars[0]: " + cars[0]);
console.log("Cars[1]: " + cars[1]);
console.log("Cars[2]: " + cars[2]);
//Multi Dimenstion
var Arr = [[1, 2, 3,], [4, 5, 6]];
console.log(Arr[0][0]);
console.log(Arr[0][1]);
console.log(Arr[0][2]);
console.log();
console.log(Arr[1][0]);
console.log(Arr[1][1]);
console.log(Arr[1][2]);
//Array By using Array object
var Aobj = new Array("Shubham", "Khushal", "Vishnu");
for (var i = 0; i < Aobj.length; i++) {
    console.log(Aobj[i]);
}
for (var _i = 0, Aobj_1 = Aobj; _i < Aobj_1.length; _i++) {
    var c = Aobj_1[_i];
    console.log(c);
}
//Passing Arrays in fuction
var arrparse = new Array("Nayan", "Dev", "Dhanush");
function show(a) {
    for (var i_1 = 0; i_1 < a.length; i_1++) {
        console.log(arrparse[i_1]);
    }
}
show(arrparse);
//TypeScript with Spread operator
var arr1 = [1, 2, 3];
var arr2 = [4, 5, 6];
var copyArray = __spreadArray([], arr1, true);
console.log("Copy Array With Spread: " + copyArray);
var copyArray1 = [arr1];
console.log("Copy Array Without Spread: " + copyArray1);
var newArray = __spreadArray(__spreadArray([], arr1, true), [7, 8], false);
console.log("New Array With Spread: " + newArray);
var newArray1 = [arr1, 7, 8];
console.log("New Array Without Spread: " + newArray1);
var mergedArray = __spreadArray(__spreadArray([], arr1, true), arr2, true);
console.log("Merged Array: " + mergedArray);
