var tuple=[1,"Yogiraj","Chopda"];
console.log("Count before push: "+tuple.length);

tuple.push(2)
console.log("Count after push: "+tuple.length)

tuple.push("Sahil")
console.log("Count after push: "+tuple.length)

console.log(tuple)

console.log(tuple.pop()+" popped from the tuple") // removes and returns the last item
console.log("Count after pop "+tuple.length)


console.log(tuple)