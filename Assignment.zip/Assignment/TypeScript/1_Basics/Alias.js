//Alise
var demo;
demo = 10;
console.log(demo);
var U;
U = 11;
console.log(U);
U = "UnionType";
console.log(U);
