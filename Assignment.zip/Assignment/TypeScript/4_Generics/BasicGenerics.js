//Generics
function generic(val) {
    console.log("Values : " + val);
    return val;
}
var num = [1, 2];
console.log(generic(num));
var str = ["Shubham", "Chaudhari"];
console.log(generic(str));
