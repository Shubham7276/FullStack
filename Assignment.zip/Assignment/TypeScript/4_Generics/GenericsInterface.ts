interface DTOptions<T> {
    [name: string]: T
    
    // name:T;
}

// let inBoolOptions: DTOptions<boolean> = {
//     'disabled': false,
//     'visible': true
// };

// let inBoolOptions1: DTOptions<number>={
//     "Num1":11
    
// }

class demo<T> implements DTOptions<T>{
    name:T;
    show(d:T){
        this.name=d;
    }
}

var d1=new demo()
d1.show(5555)
console.log(d1)


// EXERCISE: Implements the example as shown above with key-value array object and generic by means of interface inheritance in class.
