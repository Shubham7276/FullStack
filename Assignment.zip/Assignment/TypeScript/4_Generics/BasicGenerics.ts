//Generics

function generic<t>(val:t[]): t[]{
    console.log("Values : "+ val)
    return val
}

let num=[1,2]
console.log(generic<number>(num));

let str=["Shubham","Chaudhari"];
console.log(generic<string>(str))