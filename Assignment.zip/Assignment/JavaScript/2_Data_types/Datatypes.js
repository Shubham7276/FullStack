
// Primitive datatype

var num=1000;
var str="Deva";
var bool=true;

//Check a datatype of value use typeof fun

document.write("<br/>"+typeof(num));
document.write("<br/>"+typeof(str));
document.write("<br/>"+typeof(bool));

//non primitive
// 1. Object

 let obj = new Object();
 document.write("<br/>"+typeof(obj));
 document.write("<br/>"+obj.FirstName+""+obj.Lastname);


 // JSON = Javascript Object Notation

 var student ={
     roll_No: "2",
     Name:"Vivek",
     Class: "Mca"
 }

 document.write("<br/>"+student.roll_No+" "+student.Name+" "+student.Class)
 
 //Array datatype
 
 var s=["1","Vivek","BCA"]

 document.write("<br/>"+s[0])
 document.write("<br/>"+s[1])
 document.write("<br/>"+s[2])

 //Function datatype

 var demo=function(){
     return "Hello World....!";
 }

 document.write("<br/>"+demo());