//Arithmatic opertation
let a=10,b=10;

var sum=a+b,sub=a-b,mul=a*b,div=a/b;

document.write(sum,"<br/>"+sub,"<br/>"+mul,"<br/>"+div);

var pow=5**2;
document.write("<br/>"+pow);

//Assignment operator
let x=10;
x+=5;
document.write("<br/>"+x);

//Conditional operator == equal to value

let p=10,q="10";

if(p==q){
    document.write("<br/>Same")
}
else{
    document.write("<br/>Not Same")
}


// === equal to value and datatype


if(p===q){
    document.write("<br/>Same")
}
else{
    document.write("<br/>Not Same<br/>")
}

//Array instace of

var z=["BMW","Hondai","Audi"]
document.write(z instanceof Array);
document.write(typeof(z))

class student{
    constructor(name,roll){
        this.name=name;
        this.roll=roll;
    }
}

var v=new student("Nikhil",40);
document.write("<br/>");
document.write(v instanceof Object)
document.write("<br/>");

document.write(v.name+v.roll);