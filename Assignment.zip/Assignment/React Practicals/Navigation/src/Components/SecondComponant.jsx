import React from "react";

class SecondComponant extends React.Component{
    render(){
        const internal={fontSize:"40px"}
        return(
            <h1 style={internal}>Second Componant using internal Style </h1>
        );
    }
}

export default SecondComponant;

