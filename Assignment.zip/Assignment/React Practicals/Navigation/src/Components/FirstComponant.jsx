import React from "react";

class FirstComponant extends React.Component{
    render(){
        return(
            //inline style
            <h1 style={{fontSize:'50px',color:'red'}}>First Componant <span>using Inline Style</span></h1>
        )
    }
}

export default FirstComponant;