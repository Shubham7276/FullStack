import logo from './logo.svg';
import './App.css';

import { BrowserRouter, Routes, Route } from "react-router-dom";
import FirstComponant from './Components/FirstComponant';
import SecondComponant from './Components/SecondComponant';
import ThirdComponant from './Components/ThirdComponant';
import NavBar from './Components/Navbar';


function App() {
  return (
    // <>
    // <FirstComponant></FirstComponant>
    // <SecondComponant></SecondComponant>
    // <ThirdComponant></ThirdComponant>
    // </>
    <BrowserRouter>
    <NavBar/>
      <Routes>
        <Route path='/' element={<FirstComponant/>}></Route>
        <Route path='/SecondComponant' element={<SecondComponant/>}></Route>
        <Route path="/ThirdComponant" element={<ThirdComponant/>}></Route>
      </Routes>
    </BrowserRouter>

  );
}

export default App;
