import React, { Component } from 'react'
import ReactDOM from 'react-dom'

class ComponentAPIDemo extends Component{
    constructor(){
        super();
        this.findDemo1= this.findDemo1.bind(this)
        this.findDemo2= this.findDemo2.bind(this)
    };

    findDemo1(){
        var Div1 = document.getElementById('Div1');
        ReactDOM.findDOMNode(Div1).style.color='red';
    }

    findDemo2(){
        var Div2 = document.getElementById('Div2');
        ReactDOM.findDOMNode(Div2).style.color='blue';
    }

    render(){
        return(
            <div>
                <button onClick={this.findDemo1}>FIND DOM(Document Object Model) NODE 1</button>
                <button onClick={this.findDemo2}>FIND DOM(Document Object Model) NODE 2</button>
                <h3 id = "Div1">Demo Node1</h3>
                <h3 id = "Div2">Demo Node2</h3>
            </div>
        )
    }
}
export default ComponentAPIDemo;