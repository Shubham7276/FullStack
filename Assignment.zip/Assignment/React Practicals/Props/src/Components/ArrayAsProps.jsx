import React from "react";
import ReactDOM  from "react-dom";

class ArrayAsProps extends React.Component{
    render(){
        return(
            <div>
                   <h1>
                        {this.props.persons.map((per,index) => <>Person:{index + 1} - {per}<br /></>)}
                    </h1>
                </div>
           )
    }
}

ArrayAsProps.defaultProps={persons: ['Shubham Chaudhari','Khushal Sonar','Vishnu Mahindalekar']}
ReactDOM.render(<ArrayAsProps/>,document.getElementById('root'));


export default ArrayAsProps;