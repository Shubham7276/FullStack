import React from 'react'

class ParentRenderProps extends React.Component{
    render(){
        return(
            <ChildRenderProps
            demo={()=>{
                return(
                    <div>
                        <h3>
                        I am coming from parent sample render props.
                        </h3>
                    </div>
                )
            }}
            />
        )
    }
}

// Chail Component getting render props

class ChildRenderProps extends React.Component{
    render(){
        return(
            <div>
                <h2>Im Child render perop Componant</h2>
                {this.props.demo()}
            </div>
        )
    }
}


export default ParentRenderProps