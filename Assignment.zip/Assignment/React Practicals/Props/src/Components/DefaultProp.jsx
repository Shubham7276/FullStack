import React, { Component } from 'react';

class DefaultProp extends Component{
    render(){
        return(
            <div>
                <h1>Name:{this.props.name}</h1>
                <h1>Gender:{this.props.gender}</h1>
                <hr />
            </div>
        );
    }
}

DefaultProp.defaultProps = {
    name: "Shubham",
    gender:"Male"
  }

export default DefaultProp;