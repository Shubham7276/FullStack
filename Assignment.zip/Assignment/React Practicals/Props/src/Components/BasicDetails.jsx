import React from "react";
import ReactDom from "react-dom";


function Person(props){
    return(
        <>
        <h2>My Full Name is {props.personeData.firstName + " " + props.personeData.lastName}</h2>
        </>
    )

}

function BasicDetails(){
    const personeInfo = {firstName:'Shubham',lastName:'Chaudhari'}
    return(
        <>
        <Person personeData={personeInfo}/>
        </>
    )
}
ReactDom.render(<BasicDetails/>,document.getElementById('root'));

export default BasicDetails;

