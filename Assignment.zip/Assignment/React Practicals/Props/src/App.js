import logo from './logo.svg';
import './App.css';

//import { BrowserRouter, Routes, Route } from "react-router-dom";
//import BasicDetails from './Components/BasicDetails';
//import JobDetails from './Components/JobDetails';
import ArrayAsProps from './Components/ArrayAsProps';
import DefaultProp from './Components/DefaultProp';
import JobDetails from './Components/JobDetails';
import ParentRenderProps from './Components/Renderpropdemo';
import PersoneCompany from './Components/RenderPropAdvanced';



function App() {
  return (
    
  //Default prop 

  // <DefaultProp></DefaultProp>
  //<DefaultProp name="Khushal" gender="Male"></DefaultProp>


  //<JobDetails></JobDetails>

  //Props As Array
  //  <ArrayAsProps/>   

  //Renderprops Array
  // <ParentRenderProps></ParentRenderProps>

  //Renderprops Advanced
  <PersoneCompany></PersoneCompany>
   
    

  );
}

export default App;
