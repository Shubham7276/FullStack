import { forwardRef, useImperativeHandle } from "react";
import React from 'react'

const ChildComp = forwardRef((props, ref)=>{
    
    

})

export default ChildComp;
