import './App.css';
import ChildComp from './Components/Demo';
//import FirstRef from './Components/FirstRefDemo';
//import SecondRef from './Components/SecondRefDemo';
// import UseRefDemo from './Components/ThirdRefDemo';
// import StopWatch from './Components/StopWatch';
import ParentComp from './Components/RefBindingwithParent';


function App() {
  return (
    
    //<FirstRef/>
    //<SecondRef/>
    // <UseRefDemo/>
    // <StopWatch/>
    <ParentComp/>
    // <ChildComp/>
  );
}

export default App;
