import './App.css';
import MiniDrawer from './Components/drawer'

function App() {
  return (
    <MiniDrawer/>
  );
}

export default App;
