import './App.css';
import CustomHook1 from './Components/CustomHook1';
import CustomHook2 from './Components/CustomHook2';
import UserEffectdemo from './Components/useEffect';


function App() {
  return (
    
     <> 
    <UserEffectdemo/>
    {/* <CustomHook1/> */}
    {/* <CustomHook2/> */}
     </> 
  );
}

export default App;
