import React from 'react';
import useCustomReactHook from './useCustomReactHook';

//importing custom hook


function CustomHook1() {

    const clickedButton = useCustomReactHook(0,"CustomHook1")
  return (
    <div>
        <h1>This is the CustomHookComponent</h1>
        <button onClick={clickedButton}> Click Here!</button>
    </div>
  )
}

export default CustomHook1