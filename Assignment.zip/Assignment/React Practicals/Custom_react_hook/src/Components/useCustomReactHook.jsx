import {useState , useEffect} from "react";


function useCustomReactHook(init, compoName) {
    const [counter, setCounter] = useState(init)

    function resetCounter(){
        setCounter(counter + 1);
    }

    useEffect(()=>{
        alert(`The button of the ${compoName} is clicked ${counter} time.`);
    },[counter, compoName])
    

  return (

    resetCounter
  )
}

export default useCustomReactHook