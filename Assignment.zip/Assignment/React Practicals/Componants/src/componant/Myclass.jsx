import React from 'react'

class Myclass extends React.Component{
    
    render(){
        
        return <h1>First Class Componant</h1>
    }
}

export default Myclass;