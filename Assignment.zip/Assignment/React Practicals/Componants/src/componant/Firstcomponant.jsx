// import React from "react";
import Firstchild from "./Firstchild";
function Firstcomponant(){
    return(
    <div>
    <h3>First Componant</h3>
    <Firstchild/>
    </div>
    );
}

export default Firstcomponant;