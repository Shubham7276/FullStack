// import React from 'react'



function Thirdcomponant(){
    return(
        <h1>Helloooo</h1>
    )
}

export default Thirdcomponant;
