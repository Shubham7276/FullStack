import React from "react";

function Secondcomponant(){
    return(
        <h3>Second Componant</h3>
    );
}

export default Secondcomponant;